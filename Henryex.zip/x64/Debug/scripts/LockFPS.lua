-- LOCK FPS

local RS = game:GetService("ReplicatedStorage")
local RUNS = game:GetService("RunService")

local AddTextures = function()
    for i,x in pairs(game:GetService("Workspace"):GetDescendants()) do
        if x:IsA("Decal") then
            x.Transparency=0;
        end
        if x:IsA("Texture") then
            x.Transparency=0;
        end
        if x.Parent.Name == "Baseplate" then
            x.Transparency = 0.5;
        end
    end
end

if RS:FindFirstChild("Synapse Plus") then
    local SP = RS:WaitForChild("Synapse Plus")
    SP:FindFirstChild("UnlockFPS").Value = false
    AddTextures();
else
    local SP = Instance.new("Folder",RS)
    SP.Name = "Synapse Plus"
    
    local UF = Instance.new("BoolValue",SP)
    UF.Name = "UnlockFPS"
    UF.Value=false
    AddTextures()
end

RUNS.RenderStepped:Connect(function() 
    if RS:FindFirstChild("Synapse Plus") then
        if RS:FindFirstChild("UnlockFPS") then
            RS['UnlockFPS'].Value= false
            AddTextures();
        end
    end
end)