while true do
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local Backpack = LocalPlayer:WaitForChild("Backpack")
local Character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()

local tool = Backpack:FindFirstChild("FreeSlap")
if tool then
    tool.Parent = Character
end

for _, player in ipairs(Players:GetPlayers()) do
    if player ~= LocalPlayer and player.Character then
        local args = {
            "slash",
            player.Character,
            Vector3.new(2^1023,2^1023,2^1023) 
        }

        Character:WaitForChild("FreeSlap"):WaitForChild("Event"):FireServer(unpack(args))
    end
end
task.wait(0.1)
end