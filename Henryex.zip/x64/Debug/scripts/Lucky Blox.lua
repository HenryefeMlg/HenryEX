--//To Fly G
--//Open And Close
--//Made By CJSPIERS
-- Gui to Lua
-- Version: 3.2

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local Blocks = Instance.new("Frame")
local UICorner = Instance.new("UICorner")
local UIGradient = Instance.new("UIGradient")
local WSTxt = Instance.new("TextLabel")
local Block1 = Instance.new("Frame")
local UICorner_2 = Instance.new("UICorner")
local UIGradient_2 = Instance.new("UIGradient")
local WSTxt_2 = Instance.new("TextLabel")
local LuckyBlock = Instance.new("TextButton")
local Block2 = Instance.new("Frame")
local UICorner_3 = Instance.new("UICorner")
local UIGradient_3 = Instance.new("UIGradient")
local WSTxt_3 = Instance.new("TextLabel")
local SuperLuckyBlock = Instance.new("TextButton")
local Block3 = Instance.new("Frame")
local UICorner_4 = Instance.new("UICorner")
local UIGradient_4 = Instance.new("UIGradient")
local WSTxt_4 = Instance.new("TextLabel")
local DiamondLuckyBlock = Instance.new("TextButton")
local Block4 = Instance.new("Frame")
local UICorner_5 = Instance.new("UICorner")
local UIGradient_5 = Instance.new("UIGradient")
local WSTxt_5 = Instance.new("TextLabel")
local RainbowLuckyBlock = Instance.new("TextButton")
local Block5 = Instance.new("Frame")
local UICorner_6 = Instance.new("UICorner")
local UIGradient_6 = Instance.new("UIGradient")
local WSTxt_6 = Instance.new("TextLabel")
local GalaxyLuckyBlock = Instance.new("TextButton")
local OpenButton1 = Instance.new("TextButton")
local Character = Instance.new("Frame")
local UICorner_7 = Instance.new("UICorner")
local UIGradient_7 = Instance.new("UIGradient")
local WSTxt_7 = Instance.new("TextLabel")
local OpenButton2 = Instance.new("TextButton")
local WSpeed = Instance.new("Frame")
local UICorner_8 = Instance.new("UICorner")
local UIGradient_8 = Instance.new("UIGradient")
local Set = Instance.new("TextButton")
local Amount = Instance.new("TextBox")
local UICorner_9 = Instance.new("UICorner")
local WSTxt_8 = Instance.new("TextLabel")
local JHeight = Instance.new("Frame")
local UICorner_10 = Instance.new("UICorner")
local UIGradient_9 = Instance.new("UIGradient")
local JsET = Instance.new("TextButton")
local JSetAmount = Instance.new("TextBox")
local UICorner_11 = Instance.new("UICorner")
local WSTxt_9 = Instance.new("TextLabel")
local WSTxt_10 = Instance.new("TextLabel")
local Fly = Instance.new("Frame")
local UICorner_12 = Instance.new("UICorner")
local UIGradient_10 = Instance.new("UIGradient")
local FlyButton = Instance.new("TextButton")
local WSTxt_11 = Instance.new("TextLabel")
local ESP = Instance.new("Frame")
local UICorner_13 = Instance.new("UICorner")
local UIGradient_11 = Instance.new("UIGradient")
local ESPButton = Instance.new("TextButton")
local ESP_2 = Instance.new("TextLabel")
local CreditsFrame = Instance.new("Frame")
local UICorner_14 = Instance.new("UICorner")
local UIGradient_12 = Instance.new("UIGradient")
local WSTxt_12 = Instance.new("TextLabel")
local Block1_2 = Instance.new("Frame")
local UICorner_15 = Instance.new("UICorner")
local UIGradient_13 = Instance.new("UIGradient")
local WSTxt_13 = Instance.new("TextLabel")
local OpenButton4 = Instance.new("TextButton")
local TeleportFrame = Instance.new("Frame")
local UICorner_16 = Instance.new("UICorner")
local UIGradient_14 = Instance.new("UIGradient")
local WSTxt_14 = Instance.new("TextLabel")
local OpenButton3 = Instance.new("TextButton")
local List = Instance.new("ScrollingFrame")
local UIGradient_15 = Instance.new("UIGradient")
local Username = Instance.new("Frame")
local UICorner_17 = Instance.new("UICorner")
local UIGradient_16 = Instance.new("UIGradient")
local Display = Instance.new("TextLabel")
local TPButton = Instance.new("TextButton")
local UICorner_18 = Instance.new("UICorner")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Frame.BackgroundTransparency = 1.000
Frame.BorderColor3 = Color3.fromRGB(0, 0, 0)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.0565217398, 0, 0.0109756095, 0)
Frame.Size = UDim2.new(0, 348, 0, 728)

Blocks.Name = "Blocks"
Blocks.Parent = Frame
Blocks.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Blocks.BorderColor3 = Color3.fromRGB(0, 0, 0)
Blocks.BorderSizePixel = 0
Blocks.Position = UDim2.new(0.583304048, 0, 0.0102263279, 0)
Blocks.Size = UDim2.new(0, 169, 0, 44)

UICorner.Parent = Blocks

UIGradient.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient.Rotation = 90
UIGradient.Parent = Blocks

WSTxt.Name = "WSTxt"
WSTxt.Parent = Blocks
WSTxt.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt.BackgroundTransparency = 1.000
WSTxt.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt.BorderSizePixel = 0
WSTxt.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt.Size = UDim2.new(0, 169, 0, 44)
WSTxt.Font = Enum.Font.Unknown
WSTxt.Text = "Blocks"
WSTxt.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt.TextScaled = true
WSTxt.TextSize = 14.000
WSTxt.TextStrokeTransparency = 0.000
WSTxt.TextWrapped = true

Block1.Name = "Block1"
Block1.Parent = Blocks
Block1.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Block1.BorderColor3 = Color3.fromRGB(0, 0, 0)
Block1.BorderSizePixel = 0
Block1.Position = UDim2.new(-0.00249485718, 0, 1.16981673, 0)
Block1.Size = UDim2.new(0, 169, 0, 44)

UICorner_2.Parent = Block1

UIGradient_2.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_2.Rotation = 90
UIGradient_2.Parent = Block1

WSTxt_2.Name = "WSTxt"
WSTxt_2.Parent = Block1
WSTxt_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_2.BackgroundTransparency = 1.000
WSTxt_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_2.BorderSizePixel = 0
WSTxt_2.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_2.Size = UDim2.new(0, 169, 0, 44)
WSTxt_2.Font = Enum.Font.Unknown
WSTxt_2.Text = "Lucky Block"
WSTxt_2.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_2.TextScaled = true
WSTxt_2.TextSize = 14.000
WSTxt_2.TextStrokeTransparency = 0.000
WSTxt_2.TextWrapped = true

LuckyBlock.Name = "LuckyBlock"
LuckyBlock.Parent = Block1
LuckyBlock.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
LuckyBlock.BackgroundTransparency = 1.000
LuckyBlock.BorderColor3 = Color3.fromRGB(0, 0, 0)
LuckyBlock.BorderSizePixel = 0
LuckyBlock.Position = UDim2.new(-0.00591715984, 0, 0, 0)
LuckyBlock.Size = UDim2.new(0, 170, 0, 44)
LuckyBlock.ZIndex = 5
LuckyBlock.Font = Enum.Font.SourceSans
LuckyBlock.Text = ""
LuckyBlock.TextColor3 = Color3.fromRGB(0, 0, 0)
LuckyBlock.TextSize = 14.000

Block2.Name = "Block2"
Block2.Parent = Blocks
Block2.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Block2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Block2.BorderSizePixel = 0
Block2.Position = UDim2.new(-0.00249485718, 0, 2.30618048, 0)
Block2.Size = UDim2.new(0, 169, 0, 44)

UICorner_3.Parent = Block2

UIGradient_3.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_3.Rotation = 90
UIGradient_3.Parent = Block2

WSTxt_3.Name = "WSTxt"
WSTxt_3.Parent = Block2
WSTxt_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_3.BackgroundTransparency = 1.000
WSTxt_3.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_3.BorderSizePixel = 0
WSTxt_3.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_3.Size = UDim2.new(0, 169, 0, 44)
WSTxt_3.Font = Enum.Font.Unknown
WSTxt_3.Text = "Super LuckyBlock"
WSTxt_3.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_3.TextScaled = true
WSTxt_3.TextSize = 14.000
WSTxt_3.TextStrokeTransparency = 0.000
WSTxt_3.TextWrapped = true

SuperLuckyBlock.Name = "SuperLuckyBlock"
SuperLuckyBlock.Parent = Block2
SuperLuckyBlock.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
SuperLuckyBlock.BackgroundTransparency = 1.000
SuperLuckyBlock.BorderColor3 = Color3.fromRGB(0, 0, 0)
SuperLuckyBlock.BorderSizePixel = 0
SuperLuckyBlock.Position = UDim2.new(-0.00591715984, 0, 0, 0)
SuperLuckyBlock.Size = UDim2.new(0, 170, 0, 44)
SuperLuckyBlock.ZIndex = 5
SuperLuckyBlock.Font = Enum.Font.SourceSans
SuperLuckyBlock.Text = ""
SuperLuckyBlock.TextColor3 = Color3.fromRGB(0, 0, 0)
SuperLuckyBlock.TextSize = 14.000

Block3.Name = "Block3"
Block3.Parent = Blocks
Block3.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Block3.BorderColor3 = Color3.fromRGB(0, 0, 0)
Block3.BorderSizePixel = 0
Block3.Position = UDim2.new(-0.00249485718, 0, 3.44254398, 0)
Block3.Size = UDim2.new(0, 169, 0, 44)

UICorner_4.Parent = Block3

UIGradient_4.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_4.Rotation = 90
UIGradient_4.Parent = Block3

WSTxt_4.Name = "WSTxt"
WSTxt_4.Parent = Block3
WSTxt_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_4.BackgroundTransparency = 1.000
WSTxt_4.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_4.BorderSizePixel = 0
WSTxt_4.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_4.Size = UDim2.new(0, 169, 0, 44)
WSTxt_4.Font = Enum.Font.Unknown
WSTxt_4.Text = "Diamond LuckyBlock"
WSTxt_4.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_4.TextScaled = true
WSTxt_4.TextSize = 14.000
WSTxt_4.TextStrokeTransparency = 0.000
WSTxt_4.TextWrapped = true

DiamondLuckyBlock.Name = "DiamondLuckyBlock"
DiamondLuckyBlock.Parent = Block3
DiamondLuckyBlock.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
DiamondLuckyBlock.BackgroundTransparency = 1.000
DiamondLuckyBlock.BorderColor3 = Color3.fromRGB(0, 0, 0)
DiamondLuckyBlock.BorderSizePixel = 0
DiamondLuckyBlock.Position = UDim2.new(-0.00591715984, 0, 0, 0)
DiamondLuckyBlock.Size = UDim2.new(0, 170, 0, 44)
DiamondLuckyBlock.ZIndex = 5
DiamondLuckyBlock.Font = Enum.Font.SourceSans
DiamondLuckyBlock.Text = ""
DiamondLuckyBlock.TextColor3 = Color3.fromRGB(0, 0, 0)
DiamondLuckyBlock.TextSize = 14.000

Block4.Name = "Block4"
Block4.Parent = Blocks
Block4.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Block4.BorderColor3 = Color3.fromRGB(0, 0, 0)
Block4.BorderSizePixel = 0
Block4.Position = UDim2.new(-0.00249485718, 0, 4.57890749, 0)
Block4.Size = UDim2.new(0, 169, 0, 44)

UICorner_5.Parent = Block4

UIGradient_5.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_5.Rotation = 90
UIGradient_5.Parent = Block4

WSTxt_5.Name = "WSTxt"
WSTxt_5.Parent = Block4
WSTxt_5.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_5.BackgroundTransparency = 1.000
WSTxt_5.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_5.BorderSizePixel = 0
WSTxt_5.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_5.Size = UDim2.new(0, 169, 0, 44)
WSTxt_5.Font = Enum.Font.Unknown
WSTxt_5.Text = "Rainbow LuckyBlock"
WSTxt_5.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_5.TextScaled = true
WSTxt_5.TextSize = 14.000
WSTxt_5.TextStrokeTransparency = 0.000
WSTxt_5.TextWrapped = true

RainbowLuckyBlock.Name = "RainbowLuckyBlock"
RainbowLuckyBlock.Parent = Block4
RainbowLuckyBlock.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
RainbowLuckyBlock.BackgroundTransparency = 1.000
RainbowLuckyBlock.BorderColor3 = Color3.fromRGB(0, 0, 0)
RainbowLuckyBlock.BorderSizePixel = 0
RainbowLuckyBlock.Position = UDim2.new(-0.00591715984, 0, 0, 0)
RainbowLuckyBlock.Size = UDim2.new(0, 170, 0, 44)
RainbowLuckyBlock.ZIndex = 5
RainbowLuckyBlock.Font = Enum.Font.SourceSans
RainbowLuckyBlock.Text = ""
RainbowLuckyBlock.TextColor3 = Color3.fromRGB(0, 0, 0)
RainbowLuckyBlock.TextSize = 14.000

Block5.Name = "Block5"
Block5.Parent = Blocks
Block5.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Block5.BorderColor3 = Color3.fromRGB(0, 0, 0)
Block5.BorderSizePixel = 0
Block5.Position = UDim2.new(-0.00249485718, 0, 5.715271, 0)
Block5.Size = UDim2.new(0, 169, 0, 44)

UICorner_6.Parent = Block5

UIGradient_6.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_6.Rotation = 90
UIGradient_6.Parent = Block5

WSTxt_6.Name = "WSTxt"
WSTxt_6.Parent = Block5
WSTxt_6.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_6.BackgroundTransparency = 1.000
WSTxt_6.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_6.BorderSizePixel = 0
WSTxt_6.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_6.Size = UDim2.new(0, 169, 0, 44)
WSTxt_6.Font = Enum.Font.Unknown
WSTxt_6.Text = "Galaxy LuckyBlock"
WSTxt_6.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_6.TextScaled = true
WSTxt_6.TextSize = 14.000
WSTxt_6.TextStrokeTransparency = 0.000
WSTxt_6.TextWrapped = true

GalaxyLuckyBlock.Name = "GalaxyLuckyBlock"
GalaxyLuckyBlock.Parent = Block5
GalaxyLuckyBlock.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
GalaxyLuckyBlock.BackgroundTransparency = 1.000
GalaxyLuckyBlock.BorderColor3 = Color3.fromRGB(0, 0, 0)
GalaxyLuckyBlock.BorderSizePixel = 0
GalaxyLuckyBlock.Position = UDim2.new(-0.00591715984, 0, 0, 0)
GalaxyLuckyBlock.Size = UDim2.new(0, 170, 0, 44)
GalaxyLuckyBlock.ZIndex = 5
GalaxyLuckyBlock.Font = Enum.Font.SourceSans
GalaxyLuckyBlock.Text = ""
GalaxyLuckyBlock.TextColor3 = Color3.fromRGB(0, 0, 0)
GalaxyLuckyBlock.TextSize = 14.000

OpenButton1.Name = "OpenButton1"
OpenButton1.Parent = Blocks
OpenButton1.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
OpenButton1.BackgroundTransparency = 1.000
OpenButton1.BorderColor3 = Color3.fromRGB(0, 0, 0)
OpenButton1.BorderSizePixel = 0
OpenButton1.Position = UDim2.new(-0.00591715984, 0, 0, 0)
OpenButton1.Size = UDim2.new(0, 170, 0, 44)
OpenButton1.ZIndex = 5
OpenButton1.Font = Enum.Font.SourceSans
OpenButton1.Text = ""
OpenButton1.TextColor3 = Color3.fromRGB(0, 0, 0)
OpenButton1.TextSize = 14.000
OpenButton1.MouseButton1Down:Connect(function()
	Block1.Visible =  not Block1.Visible
	Block2.Visible = not Block2.Visible
	Block3.Visible = not Block3.Visible
	Block4.Visible = not Block4.Visible
	Block5.Visible = not Block5.Visible
end)

Character.Name = "Character"
Character.Parent = Frame
Character.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Character.BorderColor3 = Color3.fromRGB(0, 0, 0)
Character.BorderSizePixel = 0
Character.Position = UDim2.new(0.0714285746, 0, 0.0109756095, 0)
Character.Size = UDim2.new(0, 169, 0, 44)

UICorner_7.Parent = Character

UIGradient_7.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_7.Rotation = 90
UIGradient_7.Parent = Character

WSTxt_7.Name = "WSTxt"
WSTxt_7.Parent = Character
WSTxt_7.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_7.BackgroundTransparency = 1.000
WSTxt_7.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_7.BorderSizePixel = 0
WSTxt_7.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_7.Size = UDim2.new(0, 169, 0, 44)
WSTxt_7.Font = Enum.Font.Unknown
WSTxt_7.Text = "Character"
WSTxt_7.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_7.TextScaled = true
WSTxt_7.TextSize = 14.000
WSTxt_7.TextStrokeTransparency = 0.000
WSTxt_7.TextWrapped = true

OpenButton2.Name = "OpenButton2"
OpenButton2.Parent = Character
OpenButton2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
OpenButton2.BackgroundTransparency = 1.000
OpenButton2.BorderColor3 = Color3.fromRGB(0, 0, 0)
OpenButton2.BorderSizePixel = 0
OpenButton2.Position = UDim2.new(-0.00591715984, 0, 0, 0)
OpenButton2.Size = UDim2.new(0, 170, 0, 44)
OpenButton2.ZIndex = 5
OpenButton2.Font = Enum.Font.SourceSans
OpenButton2.Text = ""
OpenButton2.TextColor3 = Color3.fromRGB(0, 0, 0)
OpenButton2.TextSize = 14.000
OpenButton2.MouseButton1Down:Connect(function()
	Fly.Visible = not Fly.Visible
	ESP.Visible = not ESP.Visible
	WSpeed.Visible = not WSpeed.Visible
	JHeight.Visible = not JHeight.Visible
	
end)

WSpeed.Name = "WSpeed"
WSpeed.Parent = Character
WSpeed.BackgroundColor3 = Color3.fromRGB(85, 255, 0)
WSpeed.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSpeed.BorderSizePixel = 0
WSpeed.Position = UDim2.new(-0.00249485718, 0, 1.16981673, 0)
WSpeed.Size = UDim2.new(0, 169, 0, 44)

UICorner_8.Parent = WSpeed

UIGradient_8.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_8.Rotation = 90
UIGradient_8.Parent = WSpeed

Set.Name = "Set"
Set.Parent = WSpeed
Set.BackgroundColor3 = Color3.fromRGB(98, 98, 98)
Set.BackgroundTransparency = 1.000
Set.BorderColor3 = Color3.fromRGB(0, 0, 0)
Set.BorderSizePixel = 0
Set.Position = UDim2.new(-0.00591715984, 0, 0, 0)
Set.Size = UDim2.new(0, 170, 0, 44)
Set.ZIndex = 5
Set.Font = Enum.Font.SourceSans
Set.Text = ""
Set.TextColor3 = Color3.fromRGB(0, 0, 0)
Set.TextSize = 14.000

Amount.Name = "Amount"
Amount.Parent = Set
Amount.BackgroundColor3 = Color3.fromRGB(56, 56, 56)
Amount.BorderColor3 = Color3.fromRGB(0, 0, 0)
Amount.BorderSizePixel = 0
Amount.Position = UDim2.new(0.0352592915, 0, 1.11363602, 0)
Amount.Size = UDim2.new(0, 158, 0, 29)
Amount.Font = Enum.Font.SourceSans
Amount.PlaceholderColor3 = Color3.fromRGB(255, 255, 255)
Amount.Text = "Set Speed Here"
Amount.TextColor3 = Color3.fromRGB(255, 255, 255)
Amount.TextSize = 14.000
Amount.TextStrokeTransparency = 0.130
Amount.TextWrapped = true

UICorner_9.Parent = Amount

WSTxt_8.Name = "WSTxt"
WSTxt_8.Parent = WSpeed
WSTxt_8.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_8.BackgroundTransparency = 1.000
WSTxt_8.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_8.BorderSizePixel = 0
WSTxt_8.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_8.Size = UDim2.new(0, 169, 0, 44)
WSTxt_8.Font = Enum.Font.Unknown
WSTxt_8.Text = "Set"
WSTxt_8.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_8.TextScaled = true
WSTxt_8.TextSize = 14.000
WSTxt_8.TextStrokeTransparency = 0.000
WSTxt_8.TextWrapped = true

JHeight.Name = "JHeight"
JHeight.Parent = Character
JHeight.BackgroundColor3 = Color3.fromRGB(85, 255, 0)
JHeight.BorderColor3 = Color3.fromRGB(0, 0, 0)
JHeight.BorderSizePixel = 0
JHeight.Position = UDim2.new(-0.00249485718, 0, 3.07890725, 0)
JHeight.Size = UDim2.new(0, 169, 0, 44)

UICorner_10.Parent = JHeight

UIGradient_9.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_9.Rotation = 90
UIGradient_9.Parent = JHeight

JsET.Name = "JsET"
JsET.Parent = JHeight
JsET.BackgroundColor3 = Color3.fromRGB(98, 98, 98)
JsET.BackgroundTransparency = 1.000
JsET.BorderColor3 = Color3.fromRGB(0, 0, 0)
JsET.BorderSizePixel = 0
JsET.Position = UDim2.new(-0.00591715984, 0, 0, 0)
JsET.Size = UDim2.new(0, 170, 0, 44)
JsET.ZIndex = 5
JsET.Font = Enum.Font.SourceSans
JsET.Text = ""
JsET.TextColor3 = Color3.fromRGB(0, 0, 0)
JsET.TextSize = 14.000

JSetAmount.Name = "JSetAmount"
JSetAmount.Parent = JsET
JSetAmount.BackgroundColor3 = Color3.fromRGB(56, 56, 56)
JSetAmount.BorderColor3 = Color3.fromRGB(0, 0, 0)
JSetAmount.BorderSizePixel = 0
JSetAmount.Position = UDim2.new(0.0352592915, 0, 1.11363602, 0)
JSetAmount.Size = UDim2.new(0, 158, 0, 29)
JSetAmount.Font = Enum.Font.SourceSans
JSetAmount.PlaceholderColor3 = Color3.fromRGB(255, 255, 255)
JSetAmount.Text = "Jump Height Here!"
JSetAmount.TextColor3 = Color3.fromRGB(255, 255, 255)
JSetAmount.TextSize = 14.000
JSetAmount.TextStrokeTransparency = 0.130
JSetAmount.TextWrapped = true

UICorner_11.Parent = JSetAmount

WSTxt_9.Name = "WSTxt"
WSTxt_9.Parent = JHeight
WSTxt_9.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_9.BackgroundTransparency = 1.000
WSTxt_9.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_9.BorderSizePixel = 0
WSTxt_9.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_9.Size = UDim2.new(0, 169, 0, 44)
WSTxt_9.Font = Enum.Font.Unknown
WSTxt_9.Text = "Set"
WSTxt_9.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_9.TextScaled = true
WSTxt_9.TextSize = 14.000
WSTxt_9.TextStrokeTransparency = 0.000
WSTxt_9.TextWrapped = true

WSTxt_10.Name = "WSTxt"
WSTxt_10.Parent = JHeight
WSTxt_10.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_10.BackgroundTransparency = 1.000
WSTxt_10.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_10.BorderSizePixel = 0
WSTxt_10.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_10.Size = UDim2.new(0, 169, 0, 44)
WSTxt_10.Font = Enum.Font.Unknown
WSTxt_10.Text = "Set"
WSTxt_10.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_10.TextScaled = true
WSTxt_10.TextSize = 14.000
WSTxt_10.TextStrokeTransparency = 0.000
WSTxt_10.TextWrapped = true

Fly.Name = "Fly"
Fly.Parent = Character
Fly.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Fly.BorderColor3 = Color3.fromRGB(0, 0, 0)
Fly.BorderSizePixel = 0
Fly.Position = UDim2.new(-0.00249485718, 0, 5.03345299, 0)
Fly.Size = UDim2.new(0, 169, 0, 29)

UICorner_12.Parent = Fly

UIGradient_10.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_10.Rotation = 90
UIGradient_10.Parent = Fly

FlyButton.Name = "FlyButton"
FlyButton.Parent = Fly
FlyButton.BackgroundColor3 = Color3.fromRGB(98, 98, 98)
FlyButton.BackgroundTransparency = 1.000
FlyButton.BorderColor3 = Color3.fromRGB(0, 0, 0)
FlyButton.BorderSizePixel = 0
FlyButton.Position = UDim2.new(-0.00591715984, 0, 0, 0)
FlyButton.Size = UDim2.new(0, 170, 0, 29)
FlyButton.ZIndex = 5
FlyButton.Font = Enum.Font.SourceSans
FlyButton.Text = ""
FlyButton.TextColor3 = Color3.fromRGB(0, 0, 0)
FlyButton.TextSize = 14.000
FlyButton.MouseButton1Down:Connect(function()
	repeat wait() 
	until game.Players.LocalPlayer and game.Players.LocalPlayer.Character and game.Players.LocalPlayer.Character:findFirstChild("Head") and game.Players.LocalPlayer.Character:findFirstChild("Humanoid") 
	local mouse = game.Players.LocalPlayer:GetMouse() 
	repeat wait() until mouse
	local plr = game.Players.LocalPlayer 
	local torso = plr.Character.Head 
	local flying = false
	local deb = true 
	local ctrl = {f = 0, b = 0, l = 0, r = 0} 
	local lastctrl = {f = 0, b = 0, l = 0, r = 0} 
	local maxspeed = 400 
	local speed = 5000 

	function Fly() 
		local bg = Instance.new("BodyGyro", torso) 
		bg.P = 9e4 
		bg.maxTorque = Vector3.new(9e9, 9e9, 9e9) 
		bg.cframe = torso.CFrame 
		local bv = Instance.new("BodyVelocity", torso) 
		bv.velocity = Vector3.new(0,0.1,0) 
		bv.maxForce = Vector3.new(9e9, 9e9, 9e9) 
		repeat wait() 
			plr.Character.Humanoid.PlatformStand = true 
			if ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0 then 
				speed = speed+.5+(speed/maxspeed) 
				if speed > maxspeed then 
					speed = maxspeed 
				end 
			elseif not (ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0) and speed ~= 0 then 
				speed = speed-1 
				if speed < 0 then 
					speed = 0 
				end 
			end 
			if (ctrl.l + ctrl.r) ~= 0 or (ctrl.f + ctrl.b) ~= 0 then 
				bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (ctrl.f+ctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(ctrl.l+ctrl.r,(ctrl.f+ctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed 
				lastctrl = {f = ctrl.f, b = ctrl.b, l = ctrl.l, r = ctrl.r} 
			elseif (ctrl.l + ctrl.r) == 0 and (ctrl.f + ctrl.b) == 0 and speed ~= 0 then 
				bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (lastctrl.f+lastctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(lastctrl.l+lastctrl.r,(lastctrl.f+lastctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed 
			else 
				bv.velocity = Vector3.new(0,0.1,0) 
			end 
			bg.cframe = game.Workspace.CurrentCamera.CoordinateFrame * CFrame.Angles(-math.rad((ctrl.f+ctrl.b)*50*speed/maxspeed),0,0) 
		until not flying 
		ctrl = {f = 0, b = 0, l = 0, r = 0} 
		lastctrl = {f = 0, b = 0, l = 0, r = 0} 
		speed = 0 
		bg:Destroy() 
		bv:Destroy() 
		plr.Character.Humanoid.PlatformStand = false 
	end 
	mouse.KeyDown:connect(function(key) 
		if key:lower() == "g" then 
			if flying then flying = false 
			else 
				flying = true 
				Fly() 
			end 
		elseif key:lower() == "w" then 
			ctrl.f = 1 
		elseif key:lower() == "s" then 
			ctrl.b = -1 
		elseif key:lower() == "a" then 
			ctrl.l = -1 
		elseif key:lower() == "d" then 
			ctrl.r = 1 
		end 
	end) 
	mouse.KeyUp:connect(function(key) 
		if key:lower() == "w" then 
			ctrl.f = 0 
		elseif key:lower() == "s" then 
			ctrl.b = 0 
		elseif key:lower() == "a" then 
			ctrl.l = 0 
		elseif key:lower() == "d" then 
			ctrl.r = 0 
		end 
	end)
	Fly()
	
	
end)

WSTxt_11.Name = "WSTxt"
WSTxt_11.Parent = Fly
WSTxt_11.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_11.BackgroundTransparency = 1.000
WSTxt_11.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_11.BorderSizePixel = 0
WSTxt_11.Size = UDim2.new(0, 169, 0, 29)
WSTxt_11.Font = Enum.Font.Unknown
WSTxt_11.Text = "Fly"
WSTxt_11.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_11.TextScaled = true
WSTxt_11.TextSize = 14.000
WSTxt_11.TextStrokeTransparency = 0.000
WSTxt_11.TextWrapped = true

ESP.Name = "ESP"
ESP.Parent = Character
ESP.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
ESP.BorderColor3 = Color3.fromRGB(0, 0, 0)
ESP.BorderSizePixel = 0
ESP.Position = UDim2.new(-0.00249485718, 0, 5.8516345, 0)
ESP.Size = UDim2.new(0, 169, 0, 29)

UICorner_13.Parent = ESP

UIGradient_11.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_11.Rotation = 90
UIGradient_11.Parent = ESP

ESPButton.Name = "ESPButton"
ESPButton.Parent = ESP
ESPButton.BackgroundColor3 = Color3.fromRGB(98, 98, 98)
ESPButton.BackgroundTransparency = 1.000
ESPButton.BorderColor3 = Color3.fromRGB(0, 0, 0)
ESPButton.BorderSizePixel = 0
ESPButton.Position = UDim2.new(-0.00591715984, 0, 0, 0)
ESPButton.Size = UDim2.new(0, 170, 0, 29)
ESPButton.ZIndex = 5
ESPButton.Font = Enum.Font.SourceSans
ESPButton.Text = ""
ESPButton.TextColor3 = Color3.fromRGB(0, 0, 0)
ESPButton.TextSize = 14.000

ESP_2.Name = "ESP"
ESP_2.Parent = ESP
ESP_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ESP_2.BackgroundTransparency = 1.000
ESP_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
ESP_2.BorderSizePixel = 0
ESP_2.Size = UDim2.new(0, 169, 0, 29)
ESP_2.Font = Enum.Font.Unknown
ESP_2.Text = "ESP"
ESP_2.TextColor3 = Color3.fromRGB(255, 255, 255)
ESP_2.TextScaled = true
ESP_2.TextSize = 14.000
ESP_2.TextStrokeTransparency = 0.000
ESP_2.TextWrapped = true
ESPButton.MouseButton1Down:Connect(function()
	--Credits: Me aka CJSPIERS
	-- Function to create a BillboardGui above a player's head with their username
	local function createPlayerLabel(player)
		local billboardGui = Instance.new("BillboardGui")
		billboardGui.Size = UDim2.new(0, 150, 0, 70)
		billboardGui.Adornee = player.Character.Head
		billboardGui.StudsOffset = Vector3.new(0, 3, 0)
		billboardGui.Name = "PlayerLabel"

		local usernameLabel = Instance.new("TextLabel")
		usernameLabel.Parent = billboardGui
		usernameLabel.Size = UDim2.new(1, 0, 1, 0)
		usernameLabel.Position = UDim2.new(0, 0, 0.3, 0)
		usernameLabel.Text = player.Name
		usernameLabel.TextColor3 = Color3.new(1, 1, 1)
		usernameLabel.BackgroundTransparency = 1
		usernameLabel.Font = Enum.Font.SourceSansBold
		usernameLabel.TextSize = 20

		billboardGui.Parent = game.Workspace
	end

	-- Function to highlight a player's character outline with a changing rainbow color
	local function highlightPlayer(player)
		local character = player.Character
		if character then
			for _, part in ipairs(character:GetDescendants()) do
				if part:IsA("BasePart") then
					local outline = Instance.new("SelectionBox")
					outline.LineThickness = 0.05
					outline.Adornee = part
					outline.Color3 = Color3.fromRGB(255, 255, 0) -- Starting color: Yellow
					outline.SurfaceTransparency = 0.5 -- Adjust transparency to make it fill inside
					outline.SurfaceColor3 = outline.Color3 -- Set inside fill color same as outline
					outline.Parent = part

					-- Change color every second
					coroutine.wrap(function()
						while true do
							for hue = 0, 1, 0.01 do
								outline.Color3 = Color3.fromHSV(hue, 1, 1)
								outline.SurfaceColor3 = outline.Color3 -- Update inside fill color
								wait(0.1) -- Adjust speed of color change here
							end
						end
					end)()
				end
			end
		end
	end

	-- Function to handle when a new player joins the game
	local function onPlayerAdded(player)
		createPlayerLabel(player)
		highlightPlayer(player)
	end

	-- Loop through all players already in the game
	for _, player in ipairs(game.Players:GetPlayers()) do
		onPlayerAdded(player)
	end

	-- Listen for new players joining the game
	game.Players.PlayerAdded:Connect(onPlayerAdded)
	--END
end)

CreditsFrame.Name = "CreditsFrame"
CreditsFrame.Parent = Frame
CreditsFrame.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
CreditsFrame.BorderColor3 = Color3.fromRGB(0, 0, 0)
CreditsFrame.BorderSizePixel = 0
CreditsFrame.Position = UDim2.new(1.60341895, 0, 0.0102263279, 0)
CreditsFrame.Size = UDim2.new(0, 169, 0, 44)

UICorner_14.Parent = CreditsFrame

UIGradient_12.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_12.Rotation = 90
UIGradient_12.Parent = CreditsFrame

WSTxt_12.Name = "WSTxt"
WSTxt_12.Parent = CreditsFrame
WSTxt_12.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_12.BackgroundTransparency = 1.000
WSTxt_12.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_12.BorderSizePixel = 0
WSTxt_12.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_12.Size = UDim2.new(0, 169, 0, 44)
WSTxt_12.Font = Enum.Font.Unknown
WSTxt_12.Text = "Credits"
WSTxt_12.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_12.TextScaled = true
WSTxt_12.TextSize = 14.000
WSTxt_12.TextStrokeTransparency = 0.000
WSTxt_12.TextWrapped = true

Block1_2.Name = "Block1"
Block1_2.Parent = CreditsFrame
Block1_2.BackgroundColor3 = Color3.fromRGB(63, 63, 63)
Block1_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Block1_2.BorderSizePixel = 0
Block1_2.Position = UDim2.new(-0.00249485718, 0, 1.16981673, 0)
Block1_2.Size = UDim2.new(0, 169, 0, 44)

UICorner_15.Parent = Block1_2

UIGradient_13.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_13.Rotation = 90
UIGradient_13.Parent = Block1_2

WSTxt_13.Name = "WSTxt"
WSTxt_13.Parent = Block1_2
WSTxt_13.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_13.BackgroundTransparency = 1.000
WSTxt_13.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_13.BorderSizePixel = 0
WSTxt_13.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_13.Size = UDim2.new(0, 169, 0, 44)
WSTxt_13.Font = Enum.Font.Unknown
WSTxt_13.Text = "Made by: Jinx Hub"
WSTxt_13.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_13.TextScaled = true
WSTxt_13.TextSize = 14.000
WSTxt_13.TextStrokeTransparency = 0.000
WSTxt_13.TextWrapped = true

OpenButton4.Name = "OpenButton4"
OpenButton4.Parent = CreditsFrame
OpenButton4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
OpenButton4.BackgroundTransparency = 1.000
OpenButton4.BorderColor3 = Color3.fromRGB(0, 0, 0)
OpenButton4.BorderSizePixel = 0
OpenButton4.Position = UDim2.new(-0.00591715984, 0, 0, 0)
OpenButton4.Size = UDim2.new(0, 170, 0, 44)
OpenButton4.ZIndex = 5
OpenButton4.Font = Enum.Font.SourceSans
OpenButton4.Text = ""
OpenButton4.TextColor3 = Color3.fromRGB(0, 0, 0)
OpenButton4.TextSize = 14.000
OpenButton4.MouseButton1Down:Connect(function()
	Block1_2.Visible = not Block1_2.Visible
end)


UICorner_16.Parent = TeleportFrame

UIGradient_14.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_14.Rotation = 90
UIGradient_14.Parent = TeleportFrame

WSTxt_14.Name = "WSTxt"
WSTxt_14.Parent = TeleportFrame
WSTxt_14.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_14.BackgroundTransparency = 1.000
WSTxt_14.BorderColor3 = Color3.fromRGB(0, 0, 0)
WSTxt_14.BorderSizePixel = 0
WSTxt_14.Position = UDim2.new(0, 0, 8.66976677e-08, 0)
WSTxt_14.Size = UDim2.new(0, 169, 0, 44)
WSTxt_14.Font = Enum.Font.Unknown
WSTxt_14.Text = "Teleport"
WSTxt_14.TextColor3 = Color3.fromRGB(255, 255, 255)
WSTxt_14.TextScaled = true
WSTxt_14.TextSize = 14.000
WSTxt_14.TextStrokeTransparency = 0.000
WSTxt_14.TextWrapped = true

OpenButton3.Name = "OpenButton3"
OpenButton3.Parent = TeleportFrame
OpenButton3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
OpenButton3.BackgroundTransparency = 1.000
OpenButton3.BorderColor3 = Color3.fromRGB(0, 0, 0)
OpenButton3.BorderSizePixel = 0
OpenButton3.Position = UDim2.new(-0.00591715984, 0, 0, 0)
OpenButton3.Size = UDim2.new(0, 170, 0, 44)
OpenButton3.ZIndex = 5
OpenButton3.Font = Enum.Font.SourceSans
OpenButton3.Text = ""
OpenButton3.TextColor3 = Color3.fromRGB(0, 0, 0)
OpenButton3.TextSize = 14.000
OpenButton3.MouseButton1Down:Connect(function()
	List.Visible = not List.Visible
	Username.Visible = not Username.Visible
end)



UIGradient_15.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_15.Rotation = 90
UIGradient_15.Parent = List

Username.Name = "Username"
Username.Parent = List
Username.BackgroundColor3 = Color3.fromRGB(59, 59, 59)
Username.BorderColor3 = Color3.fromRGB(0, 0, 0)
Username.BorderSizePixel = 0
Username.Position = UDim2.new(0.10283272, 0, 0.0389829539, 0)
Username.Size = UDim2.new(0, 126, 0, 25)

UICorner_17.Parent = Username

UIGradient_16.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(216, 216, 216))}
UIGradient_16.Rotation = 90
UIGradient_16.Parent = Username

Display.Name = "Display"
Display.Parent = Username
Display.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Display.BackgroundTransparency = 1.000
Display.BorderColor3 = Color3.fromRGB(0, 0, 0)
Display.BorderSizePixel = 0
Display.Position = UDim2.new(-4.60185693e-05, 0, 0, 0)
Display.Size = UDim2.new(0, 126, 0, 23)
Display.Font = Enum.Font.Unknown
Display.Text = "Username"
Display.TextColor3 = Color3.fromRGB(255, 255, 255)
Display.TextScaled = true
Display.TextSize = 14.000
Display.TextStrokeTransparency = 0.000
Display.TextWrapped = true



UICorner_18.Parent = List

-- Scripts:

local function QSVBZKR_fake_script() -- Exit.Script 
	local script = Instance.new('Script', "")

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent:Destroy()
	end)
end
coroutine.wrap(QSVBZKR_fake_script)()
local function PBRF_fake_script() -- LuckyBlock.LB 
	local script = Instance.new('Script', LuckyBlock)

	script.Parent.MouseButton1Click:Connect(function()
		game.ReplicatedStorage.SpawnLuckyBlock:FireServer()
	end)
end
coroutine.wrap(PBRF_fake_script)()
local function UTCWX_fake_script() -- SuperLuckyBlock.SB 
	local script = Instance.new('Script', SuperLuckyBlock)

	script.Parent.MouseButton1Click:Connect(function()
		game.ReplicatedStorage.SpawnSuperBlock:FireServer()
	end)
end
coroutine.wrap(UTCWX_fake_script)()
local function LFKVXA_fake_script() -- DiamondLuckyBlock.DB 
	local script = Instance.new('Script', DiamondLuckyBlock)

	script.Parent.MouseButton1Click:Connect(function()
		game.ReplicatedStorage.SpawnDiamondBlock:FireServer()
	end)
end
coroutine.wrap(LFKVXA_fake_script)()
local function TBQZ_fake_script() -- RainbowLuckyBlock.RB 
	local script = Instance.new('Script', RainbowLuckyBlock)

	script.Parent.MouseButton1Click:Connect(function()
		game.ReplicatedStorage.SpawnRainbowBlock:FireServer()
	end)
end
coroutine.wrap(TBQZ_fake_script)()
local function PTVFSYM_fake_script() -- GalaxyLuckyBlock.GB 
	local script = Instance.new('Script', GalaxyLuckyBlock)

	script.Parent.MouseButton1Click:Connect(function()
		game.ReplicatedStorage.SpawnGalaxyBlock:FireServer()
	end)
end
coroutine.wrap(PTVFSYM_fake_script)()
local function BLSGOKB_fake_script() -- BG.DragGui 
	local script = Instance.new('LocalScript', "")

	local UserInputService = game:GetService("UserInputService")

	local mainframe = script.Parent
	local TopBar = mainframe
	local Camera = workspace:WaitForChild("Camera")

	local DragMousePosition
	local FramePosition

	local DragAble = false

	TopBar.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			DragAble = true
			DragMousePosition = Vector2.new(input.Position.X, input.Position.Y)
			FramePosition = Vector2.new(mainframe.Position.X.Scale, mainframe.Position.Y.Scale)
		end
	end)

	TopBar.InputEnded:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			DragAble = false
		end	
	end)

	UserInputService.InputChanged:Connect(function(input)
		if DragAble == true then
			local NewPosition = FramePosition + ((Vector2.new(input.Position.X, input.Position.Y) - DragMousePosition) / Camera.ViewportSize)
			mainframe.Position = UDim2.new(NewPosition.X, 0, NewPosition.Y, 0)
		end
	end)
end
coroutine.wrap(BLSGOKB_fake_script)()

--script two
local gui = Instance.new("ScreenGui")
gui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")

local function setWalkSpeed()
	local walkSpeed = tonumber(Amount.Text)
	if walkSpeed and walkSpeed >= 1 and walkSpeed <= 500 then
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = walkSpeed
		print("Walk speed set to:", walkSpeed)
	else
		print("Please enter a value between 1 and 500.")
	end
end

-- Connect the Set Button to the setWalkSpeed function
Set.MouseButton1Click:Connect(setWalkSpeed)

--//Script 3
local gui = Instance.new("ScreenGui")
gui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")

local function setJumpPower()
	local jumpPower = tonumber(JSetAmount.Text)
	if jumpPower and jumpPower >= 1 and jumpPower <= 150 then
		game.Players.LocalPlayer.Character.Humanoid.JumpPower = jumpPower
		print("Jump power set to:", jumpPower)
	else
		print("Please enter a valid number between 1 and 150.")
	end
end

-- Connect the Set Button to the setJumpPower function
JsET.MouseButton1Click:Connect(setJumpPower)

--//Script 4
local function createTeleportGUI()
	-- Create a ScreenGui
	local gui = Instance.new("ScreenGui")
	gui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
	
	-- Function to teleport the player to another player
	local function teleportToPlayer(player)
		local character = game.Players.LocalPlayer.Character
		if character then
			local rootPart = character:FindFirstChild("HumanoidRootPart")
			if rootPart then
				rootPart.CFrame = player.Character.HumanoidRootPart.CFrame + Vector3.new(0, 3, 0)
			end
		end
	end

	-- Get all players in the server
	local players = game.Players:GetPlayers()
	
	-- Create a button for each player
	for i, player in ipairs(players) do
		local button = Instance.new("TextButton")
		button.Size = UDim2.new(0, 120, 0, 30)
		button.Position = UDim2.new(0.5, -90, 0, i * 40)
		button.Text = player.Name
		button.Parent = List
		UICorner = true
	
	TPButton.MouseButton1Down:Connect(function()
		teleportToPlayer(player)
	end)
	end
	end


-- Create the Teleport GUI
createTeleportGUI()