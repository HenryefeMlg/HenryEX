-- This is OwlHub for ROBLOX. (OwlHub was not made by me)
-- It is a free script hub for many games on ROBLOX and has universal features too.

loadstring(game:HttpGet("https://raw.githubusercontent.com/CriShoux/OwlHub/master/OwlHub.txt"))();